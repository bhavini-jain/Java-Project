package Employeee;

import com.email.durgesh.Email;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;
import javax.swing.table.*;

public class Senior_Engineer extends JFrame implements ActionListener
{
    JFrame f;
    JLabel l1,l2,l3,l4;
    JTextField t1,t2,t3;
    JButton b,c;
    int i;
    public Senior_Engineer()
    {
        f=new JFrame("Senior Engineer");
         f.setBackground(Color.white);
         f.setLayout(null);

    
       
        
        l1 = new JLabel();
        l1.setBounds(0,0,700,500);
        l1.setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Employeee/icons/details.png"));
        l1.setIcon(i1);
        f.add(l1);
        
        l2 = new JLabel("Send Email");
        l2.setBounds(50,20,200,40);
        l2.setFont(new Font("serif",Font.BOLD,35));
        l2.setForeground(Color.black);
        l1.add(l2);
        
        l3 = new JLabel("Subject");
        l3.setBounds(50,75,200,40);
        l3.setFont(new Font("serif",Font.BOLD,20));
        l3.setForeground(Color.black);
        l1.add(l3);
        
        t2=new JTextField();
        t2.setBounds(130,75,500,50);
        l1.add(t2);
        
        l4 = new JLabel("Content");
        l4.setBounds(50,150,200,40);
        l4.setFont(new Font("serif",Font.BOLD,20));
        l4.setForeground(Color.black);
        l1.add(l4);
        
        t3=new JTextField();
        t3.setBounds(130,150,500,250);
        l1.add(t3);
        
        b=new JButton("Send");   
        
        b.setBounds(250,410,100,50);
        b.addActionListener(this);
        l1.add(b);
        
        c=new JButton("back");
        c.setBounds(400,410,100,50);   
        c.addActionListener(this);
        l1.add(c);
        
        f.setVisible(true);
        f.setSize(700,500);
        f.setLocation(550,200);
        
        
        ArrayList columnNames = new ArrayList();
        ArrayList data = new ArrayList();

        //  Connect to an MySQL Database, run query, get result set
        String url = "jdbc:mysql://localhost:3306/employee";
        String userid = "root";
        String password = "";

        String sql = "SELECT * FROM senior_engineer";

        // Java SE 7 has try-with-resources
        // This will ensure that the sql objects are closed when the program 
        // is finished with them
        try (Connection connection = DriverManager.getConnection( url, userid, password );

            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery( sql ))
        {
            ResultSetMetaData md = rs.getMetaData();
            int columns = md.getColumnCount();

            //  Get column names
            for (int i = 1; i <= columns; i++)
            {
                columnNames.add( md.getColumnName(i) );
            }

            //  Get row data
            while (rs.next())
            {
                ArrayList row = new ArrayList(columns);

                for (int i = 1; i <= columns; i++)
                {
                    row.add( rs.getObject(i) );
                }

                data.add( row );
            }
        }
        catch (SQLException e)
        {
            System.out.println( e.getMessage() );
        }

        // Create Vectors and copy over elements from ArrayLists to them
        // Vector is deprecated but I am using them in this example to keep 
        // things simple - the best practice would be to create a custom defined
        // class which inherits from the AbstractTableModel class
        Vector columnNamesVector = new Vector();
        Vector dataVector = new Vector();

        for (int i = 0; i < data.size(); i++)
        {
            ArrayList subArray = (ArrayList)data.get(i);
            Vector subVector = new Vector();
            for (int j = 0; j < subArray.size(); j++)
            {
                subVector.add(subArray.get(j));
            }
            dataVector.add(subVector);
        }

        for (int i = 0; i < columnNames.size(); i++ )
            columnNamesVector.add(columnNames.get(i));

        //  Create table with database data    
        JTable table = new JTable(dataVector, columnNamesVector)
        {
            public Class getColumnClass(int column)
            {
                for (int row = 0; row < getRowCount(); row++)
                {
                    Object o = getValueAt(row, column);

                    if (o != null)
                    {
                        return o.getClass();
                    }
                }

                return Object.class;
            }
        };
        JScrollPane scrollPane = new JScrollPane( table );
        getContentPane().add( scrollPane );

        JPanel buttonPanel = new JPanel();
        getContentPane().add( buttonPanel, BorderLayout.SOUTH );
    }
    
    public void actionPerformed(ActionEvent ae){
        	String bb = t2.getText();
        	String bb2 = t3.getText();
            if(ae.getSource() == b){
            	JOptionPane.showMessageDialog(null,"Mail send");
            	 try {
                     
             		
             		 	Connection conn = null;
             		 	Statement stmt = null;
             	    	java.awt.List Addres_name_list = new java.awt.List() ;
             	    	
             	    	String url = "jdbc:mysql://localhost:3306/employee";
             	        String userid = "root";
             	        String password = "";
             	        Class.forName("com.mysql.jdbc.Driver");
             	        System.out.println("Connecting to database...");
             	        conn = DriverManager.getConnection(url, userid, password);

             	        //STEP 4: Execute a query
             	        System.out.println("Creating statement...");
             	        stmt = conn.createStatement();
             	        String sql;
             	        sql = "select email from senior_engineer";
             	        System.out.println("sql"+sql);
             	        try (ResultSet rs = stmt.executeQuery(sql)) {
             	            while (rs.next())

             	            {
             	                String wifi_address = rs.getString("email");
                                
             	                System.out.println("email address is:"+wifi_address);
             	                Addres_name_list.add(wifi_address);
             	                Email email=new Email("employeejavaproject@gmail.com","javaproject");
     
                                email.setFrom("employeejavaproject@gmail.com","Lance Company");
                                email.setSubject(bb);
                                email.setContent(bb2,"text/html");
                                email.addRecipient(wifi_address);
                                email.send();


             	            }
             	            //STEP 6: Clean-up environment
             	        }
             	        
            	 
             	    System.out.println("Goodbye!");}
             	   /* List[] addressList2 = split(Addres_name_list);
             	  for(int i=0;i<addressList2.length;i++)
             	  {
             		email.addRecipient(addressList2[i]);
             		email.send();
             	  }
            
             }*/ catch (Exception t) {
             	t.printStackTrace();
             }
            }
            if(ae.getSource()==c){
                f.setVisible(false);
                Group_Employee ge =new Group_Employee();
                }
        }
    
    public static void main(String[] args)
    {
        Senior_Engineer frame = new Senior_Engineer();
        frame.setDefaultCloseOperation( EXIT_ON_CLOSE );
        frame.pack();
        frame.setVisible(true);
    }
}