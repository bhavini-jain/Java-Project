package Employeee;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Group_Employee implements ActionListener{
	JFrame f;
    JLabel l1,l2;
    JButton b1,b2,b3,b4,b5;

    Group_Employee(){
        f=new JFrame("Employee Detail");
        f.setBackground(Color.white);
        f.setLayout(null);

        l1 = new JLabel();
        l1.setBounds(0,0,700,500);
        l1.setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Employeee/icons/details.png"));
        l1.setIcon(i1);
        f.add(l1);

        l2 = new JLabel("Employee Groups");
        l2.setBounds(325,20,200,40);
        l2.setFont(new Font("serif",Font.BOLD,25));
        l2.setForeground(Color.black);
        l1.add(l2);

        b1=new JButton("Project Manager");
        b1.setBounds(220,80,200,40);
        b1.setFont(new Font("serif",Font.BOLD,15));
        b1.addActionListener(this);
        l1.add(b1);


        b2=new JButton("Team Leader");
        b2.setBounds(430,80,200,40);
        b2.setFont(new Font("serif",Font.BOLD,15));
        b2.addActionListener(this);
        l1.add(b2);

        b3=new JButton("Senior Engineer");
        b3.setBounds(220,140,200,40);
        b3.setFont(new Font("serif",Font.BOLD,15));
        b3.addActionListener(this);
        l1.add(b3);

        b4=new JButton("Junior Engineer");
        b4.setBounds(430,140,200,40);
        b4.setFont(new Font("serif",Font.BOLD,15));
        b4.addActionListener(this);
        l1.add(b4);
        
        b5=new JButton("Others Groups");
        b5.setBounds(325,200,200,40);
        b5.setFont(new Font("serif",Font.BOLD,15));
        b5.addActionListener(this);
        l1.add(b5);
        

        f.setVisible(true);
        f.setSize(700,500);
        f.setLocation(450,200);

    
    }
    public void actionPerformed(ActionEvent aa){
    	System.out.println("hello hey how are you");
        if(aa.getSource()==b1){
            f.setVisible(false);
            new Project_Manager();
        }
        if(aa.getSource()==b2){
            f.setVisible(false);
            new Team_Leader();
        }
        if(aa.getSource()==b3){
            f.setVisible(false);
            new Senior_Engineer();
        }
        if(aa.getSource()==b5){
            f.setVisible(false);
            new Others_Group();
        }
        if(aa.getSource()==b4){
            f.setVisible(false);
            new Junior_Engineer();
			}
            
        
    }
    

    public static void main(String[ ] args){
    	Group_Employee ge = new Group_Employee();
    	
    	
    }

}
